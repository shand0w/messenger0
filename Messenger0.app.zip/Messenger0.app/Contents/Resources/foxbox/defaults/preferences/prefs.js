pref("toolkit.defaultChromeURI", "chrome://foxbox/content/foxbox.xul");

pref("layout.spellcheckDefault", 0);

pref("browser.dom.window.dump.enabled", true);
pref("javascript.options.showInConsole", true);

pref("browser.chromeURL", "chrome://foxbox/content/foxbox.xul");
pref("tenfourfox.mp3.enabled", true);

pref("browser.download.useDownloadDir", true);
pref("browser.download.folderList", 0);
pref("browser.download.manager.showAlertOnComplete", true);
pref("browser.download.manager.showAlertInterval", 2000);
pref("browser.download.manager.retention", 2);
pref("browser.download.manager.showWhenStarting", true);
pref("browser.download.manager.useWindow", true);
pref("browser.download.manager.closeWhenDone", true);
pref("browser.download.manager.openDelay", 0);
pref("browser.download.manager.focusWhenStarting", false);
pref("browser.download.manager.flashCount", 2);

pref("dom.webnotifications.enabled", true);
pref("notification.prompt.testing", true);

pref("app.update.enabled", true);
pref("browser.formfill.enable", true);
pref("browser.formfill.saveHttpsForms", true);
pref("browser.formfill.agedWeight", 2);
pref("browser.formfill.boundaryWeight", 25);
pref("browser.formfill.bucketSize", 1);
pref("browser.formfill.debug", false);
pref("browser.formfill.expire_days", 180);
pref("browser.formfill.maxTimeGroupings", 25);
pref("browser.formfill.prefixWeight", 5);
pref("browser.formfill.timeGroupingSize", 604800);



